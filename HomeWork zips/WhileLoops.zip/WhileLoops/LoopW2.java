package WhileLoops;

public final class LoopW2 
{
	public static void main(String[] args) 
	{
		int x=1;
		while(x<=5)
		{
			System.out.println("* ");
			x++;
		}
	}
}
