package WhileLoops;

public class LoopWt15 
{
	public static void main(String[] args) 
	{
		int x=1;
		while(x<=5) 
		{
			int y=1;
			while(y<=x)
			{
				System.out.print("* ");
				y++;
			}
			int z=x;
			while(z<5)
			{
				System.out.print("  ");
				z++;
			}
			int i=x;
			while(i<5)
			{
				System.out.print("  ");
				i++;
			}
			int k=1;
			while(k<=x)
			{
				System.out.print("* ");
				k++;
			}
			System.out.println();
			x++;
		}
		
		
		x=2;
		while(x<=5) 
		{
			int y=x;
			while(y<=5)
			{
				System.out.print("* ");
				y++;
			}
			int z=1;
			while(z<x)
			{
				System.out.print("  ");
				z++;
			}
			int i=1;
			while(i<x)
			{
				System.out.print("  ");
				i++;
			}
			int k=x;
			while(k<=5)
			{
				System.out.print("* ");
				k++;
			}
			System.out.println();
			x++;
		}

	}
}
