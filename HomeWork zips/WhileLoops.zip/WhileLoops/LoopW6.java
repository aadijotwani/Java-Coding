package WhileLoops;

public class LoopW6 
{
	public static void main(String[] args) 
	{
		int x=1;
		while(x<=5)
		{
			int y=1;
			while(y<x)
			{
				System.out.print("  ");
				y++;
			}
			int z=x;
			while(z<=5)
			{
				System.out.print("* ");
				z++;
			}
			System.out.println();
			x++;
		}
	}
}
