package WhileLoops;

public class LoopW1
{
	public static void main(String[] args) 
	{
		int x=1;
		while(x<=5)
		{
			System.out.print("* ");
			x++;
		}
	}
}
