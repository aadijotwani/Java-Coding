package WhileLoops;

public class LoopW9 
{
	public static void main(String[] args) 
	{
		int x=1;
		while(x<=5)
		{
			int y=1;
			while(y<x)
			{
				System.out.print("  ");
				y++;
			}
			int z=x;
			while(z<=5)
			{
				System.out.print("* ");
				z++;
			}
			int i=x;
			while(i<5)
			{
				System.out.print("* ");
				i++;
			}
			System.out.println();
			x++;
		}
	}
}
