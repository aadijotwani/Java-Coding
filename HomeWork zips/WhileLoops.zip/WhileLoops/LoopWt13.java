package WhileLoops;

public class LoopWt13
{
	public static void main(String[] args) 
	{
		int x=1;
		while(x<=5)
		{
			int y=x;
			while(y<=5)
			{
				System.out.print("* ");
				y++;
			}
			System.out.println();
			x++;
		}
		
		x=2;
		while(x<=5) 
		{
			int y=1;
			while(y<=x)
			{
				System.out.print("* ");
				y++;
			}
			System.out.println();
			x++;
		}
	}
}
